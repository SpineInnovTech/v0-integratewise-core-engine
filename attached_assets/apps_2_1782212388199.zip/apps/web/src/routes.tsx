/**
 * IntegrateWise App Router
 *
 * Clean separation: App only (no marketing landing).
 * Marketing lives at integratewise.ai (separate codebase).
 * This app lives at app.integratewise.ai
 */

import { createBrowserRouter, Navigate } from "react-router";
import React from "react";

// Import ErrorBoundary from AppShell
import { ErrorBoundary } from "@/AppShell";

const AppShell = React.lazy(() => import("@/AppShell"));
const MockUnifiedShellPage = React.lazy(() =>
  import("@/AppShell").then((m) => ({ default: m.MockUnifiedShell }))
);
const OAuthCallbackPage = React.lazy(
  () => import("@/components/connectivity/connectors/oauth-callback")
);
const AuthCallbackPage = React.lazy(() => import("@/pages/AuthCallback"));

// Simple 404 for app domain
const NotFound = () => (
  <div className="min-h-screen bg-background flex items-center justify-center font-iw-sans">
    <div className="text-center space-y-4">
      <h1 className="text-4xl font-bold text-foreground">404</h1>
      <p className="text-muted-foreground">Page not found</p>
      <a href="/app" className="text-primary font-bold hover:underline">
        Go to app
      </a>
    </div>
  </div>
);

export const router = createBrowserRouter([
  // Root redirects to /app (app entry point)
  {
    path: "/",
    element: <Navigate to="/app" replace />,
  },

  // Clean Command Center — v0 "IntegrateWise Business Command Center" adopted as the primary OS shell
// https://v0-integrate-wise-operating-system-70r2s021o-integratewize.vercel.app/
import CommandCenter from "@/components/CommandCenter"

  {
    path: "/app",
    element: (
      <ErrorBoundary>
        <React.Suspense fallback={<div className="p-8 text-center">Loading IntegrateWise Command Center...</div>}>
          <CommandCenter />
        </React.Suspense>
      </ErrorBoundary>
    ),
  },

  // Original advanced layered shell remains available under /app/advanced
  {
    path: "/app/advanced/*",
    element: (
      <ErrorBoundary>
        <React.Suspense
          fallback={
            <div className="min-h-screen bg-background flex items-center justify-center font-iw-sans">
              <div className="text-center space-y-4">
                <div
                  className="w-10 h-10 border-2 border-t-transparent rounded-full animate-spin mx-auto"
                  style={{ borderColor: "var(--iw-forest)" }}
                />
                <p className="text-muted-foreground text-sm font-iw-mono">
                  Loading IntegrateWise...
                </p>
              </div>
            </div>
          }
        >
          <AppShell />
        </React.Suspense>
      </ErrorBoundary>
    ),
  },

  // Auth callback (CF Gateway OAuth 2.0)
  {
    path: "/auth/callback",
    element: (
      <React.Suspense
        fallback={
          <div className="min-h-screen bg-background flex items-center justify-center">
            <div
              className="w-10 h-10 border-2 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: "var(--iw-forest)" }}
            />
          </div>
        }
      >
        <AuthCallbackPage />
      </React.Suspense>
    ),
  },

  // OAuth callbacks (connector-level)
  {
    path: "/oauth/callback/:provider",
    element: (
      <React.Suspense
        fallback={
          <div className="min-h-screen bg-background flex items-center justify-center">
            <div
              className="w-10 h-10 border-2 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: "var(--iw-forest)" }}
            />
          </div>
        }
      >
        <OAuthCallbackPage />
      </React.Suspense>
    ),
  },

  // Dev-only: UnifiedShell preview — NO AUTH REQUIRED
  // Navigate to /dev/unified/work/dashboard to preview the new shell.
  // Remove this route before going to production.
  {
    path: "/dev/unified/*",
    element: (
      <React.Suspense
        fallback={
          <div
            className="min-h-screen flex items-center justify-center"
            style={{ background: "#1A3A2A" }}
          >
            <div
              className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: "#B8943F" }}
            />
          </div>
        }
      >
        <MockUnifiedShellPage />
      </React.Suspense>
    ),
  },

  // 404 - app only
  { path: "*", Component: NotFound },
]);
