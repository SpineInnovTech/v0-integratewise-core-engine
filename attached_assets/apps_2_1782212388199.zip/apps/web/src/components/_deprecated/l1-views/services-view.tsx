"use client";

export function ServicesView() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Services</h1>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}
