"use client";

export function ArchitectureView() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Architecture</h1>
      <p className="text-muted-foreground">Coming soon...</p>
    </div>
  );
}
