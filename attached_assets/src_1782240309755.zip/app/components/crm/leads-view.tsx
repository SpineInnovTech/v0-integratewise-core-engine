/**
 * LeadsView — Entity Stretch using shadcn/ui
 *
 * Sheet → detail panel (slides from right)
 * Tabs  → See & Obtain | Twin Read | Act
 * All tokens from globals.css apply automatically through shadcn/ui's CSS variable bindings.
 *
 * Real Apollo data: 5 CIOs imported Jun 2026.
 * Design system: CSS variables only. Inter font only.
 */

import { useState } from "react";
import {
  Search, Plus, Linkedin, Mail, Phone, MapPin,
  Building2, Brain, Check, Shield, FileText, GitBranch,
  NotebookPen, Calendar, UserCheck, CheckCircle2, Zap,
} from "lucide-react";

import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "../ui/sheet";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Avatar, AvatarFallback } from "../ui/avatar";
import { ScrollArea } from "../ui/scroll-area";
import { Separator } from "../ui/separator";
import { type CTXEnum } from "../spine/types";

// ─── Types ────────────────────────────────────────────────────────────────────

type LeadStage  = "New" | "Researched" | "Contacted" | "Qualified" | "Proposal" | "Won" | "Lost";
type TraceActor = "System" | "Human" | "Twin";

interface TraceEntry { ts: string; actor: TraceActor; action: string; }

interface Lead {
  id: string;
  firstName: string;
  lastName: string;
  title: string;
  company: string;
  location: string;
  region: "EU" | "UK" | "US" | "APAC" | "Other";
  score: number;
  stage: LeadStage;
  industry?: string;
  companySize?: string;
  twinRead: {
    think: string;
    understand: string;
    validate: string;
    draft: string;
    confidence: number;
    citations: string[];
  };
  trace: TraceEntry[];
}

// ─── Apollo leads — real import Jun 2026 ─────────────────────────────────────

const APOLLO_LEADS: Lead[] = [
  {
    id: "L001", firstName: "Konstantin", lastName: "Lalafaryan",
    title: "Chief Information Officer", company: "Picsart",
    location: "Germany", region: "EU", score: 100, stage: "New",
    industry: "Creative Technology · SaaS", companySize: "1,000 – 5,000",
    twinRead: {
      think: "CIO at a visual creative platform with 150M+ users. High-growth SaaS. Germany-based.",
      understand: "Picsart's CIO scope covers infrastructure scale, AI/ML tooling, and data platform reliability. Apollo data completeness is 100 — profile is verified. No prior interaction in Spine.",
      validate: "EU contact — GDPR Article 6(1)(f) applies. Outreach permissible under legitimate interest if professionally relevant. Document the basis before any contact.",
      draft: "Lead with data continuity and governance relevance to EU SaaS operations. Avoid a cold product pitch — this profile responds to architectural framing, not feature lists.",
      confidence: 68,
      citations: ["Apollo MCP import · Jun 23, 2026", "Company profile · Picsart.com"],
    },
    trace: [{ ts: "Jun 23, 2026 · 10:14 AM", actor: "System", action: "Imported via Apollo MCP — data completeness score 100" }],
  },
  {
    id: "L002", firstName: "Antoine", lastName: "Moreau",
    title: "Chief Information Officer", company: "Regnology",
    location: "London, England, United Kingdom", region: "UK", score: 100, stage: "New",
    industry: "Regulatory Technology · FinTech", companySize: "500 – 1,000",
    twinRead: {
      think: "CIO at a regulatory reporting software company serving 7,000+ financial institutions. UK-based.",
      understand: "Regnology's CIO owns data integrity, cross-border regulatory reporting, and auditability. Apollo data complete. No prior interaction. Strong relevance to governance and data lineage.",
      validate: "UK contact — ICO and PECR govern B2B outreach. Permissible if relevant to their role. Document purpose and relevance before contacting.",
      draft: "Frame around regulatory data continuity and audit trail integrity — Regnology's core product promise to their own clients. Reference cross-border reporting complexity as the shared problem.",
      confidence: 74,
      citations: ["Apollo MCP import · Jun 23, 2026", "Regnology.net · Company profile"],
    },
    trace: [{ ts: "Jun 23, 2026 · 10:14 AM", actor: "System", action: "Imported via Apollo MCP — data completeness score 100" }],
  },
  {
    id: "L003", firstName: "Gerhard", lastName: "Koestler",
    title: "Chief Information Officer", company: "Raisin",
    location: "Berlin, Berlin, Germany", region: "EU", score: 100, stage: "New",
    industry: "FinTech · Savings & Investment", companySize: "500 – 1,000",
    twinRead: {
      think: "CIO at an EU savings marketplace connecting savers to deposits across 30+ European banks. Berlin-based.",
      understand: "Raisin's CIO manages multi-jurisdiction data compliance, partner API integration, and real-time financial data pipelines. Apollo completeness 100. No prior interaction.",
      validate: "EU contact — GDPR and BaFin/ECB oversight apply. Outreach must document lawful basis. Raisin operates under EU financial services regulations.",
      draft: "Multi-partner data continuity and cross-border API governance directly maps to Raisin's 30+ bank integrations. Lead with compliance certainty — that's their liability.",
      confidence: 71,
      citations: ["Apollo MCP import · Jun 23, 2026", "Raisin.com · Company profile"],
    },
    trace: [{ ts: "Jun 23, 2026 · 10:14 AM", actor: "System", action: "Imported via Apollo MCP — data completeness score 100" }],
  },
  {
    id: "L004", firstName: "Joe", lastName: "Morris",
    title: "Chief Information Officer", company: "Hitachi Vantara",
    location: "Denver, Colorado, United States", region: "US", score: 100, stage: "New",
    industry: "Enterprise IT Infrastructure", companySize: "10,000+",
    twinRead: {
      think: "CIO at a global enterprise IT infrastructure company. Large-org buyer. Denver, US.",
      understand: "Hitachi Vantara covers data infrastructure, hybrid cloud, and OT/IT convergence for global enterprises. Apollo completeness 100. No prior interaction.",
      validate: "US contact — CAN-SPAM applies for email. Standard B2B outreach rules, no special restrictions identified.",
      draft: "Enterprise data infrastructure angle: operational continuity, data fabric, hybrid cloud governance. OT/IT convergence is their differentiator — reference it.",
      confidence: 65,
      citations: ["Apollo MCP import · Jun 23, 2026", "HitachiVantara.com · Company profile"],
    },
    trace: [{ ts: "Jun 23, 2026 · 10:14 AM", actor: "System", action: "Imported via Apollo MCP — data completeness score 100" }],
  },
  {
    id: "L005", firstName: "Felix", lastName: "Quintana",
    title: "Chief Information Officer", company: "MX",
    location: "Salt Lake City, Utah, United States", region: "US", score: 100, stage: "New",
    industry: "Financial Data Platform", companySize: "500 – 1,000",
    twinRead: {
      think: "CIO at a financial data platform serving 2,000+ banks and credit unions. Salt Lake City, US.",
      understand: "MX provides data aggregation and enrichment to financial institutions. CIO priorities: open banking APIs, data quality, real-time enrichment pipelines. Apollo completeness 100.",
      validate: "US contact — no special restrictions. MX serves regulated institutions, so compliance messaging resonates well.",
      draft: "Financial data continuity and API governance angle. Open banking and enrichment reliability are core to MX's value proposition — lead from that alignment.",
      confidence: 69,
      citations: ["Apollo MCP import · Jun 23, 2026", "MX.com · Company profile"],
    },
    trace: [{ ts: "Jun 23, 2026 · 10:14 AM", actor: "System", action: "Imported via Apollo MPC — data completeness score 100" }],
  },
];

const STAGE_ORDER: LeadStage[] = ["New", "Researched", "Contacted", "Qualified", "Proposal", "Won", "Lost"];

// ─── Small helpers ────────────────────────────────────────────────────────────

function stageVariant(stage: LeadStage): "default" | "secondary" | "outline" {
  if (stage === "Won")       return "default";
  if (stage === "Lost")      return "destructive" as any;
  if (stage === "Qualified") return "default";
  return "secondary";
}

function stageColor(stage: LeadStage): string {
  switch (stage) {
    case "Won":       return "var(--iw-success)";
    case "Lost":      return "var(--iw-danger)";
    case "Qualified": return "var(--iw-blue)";
    case "Contacted": return "var(--iw-purple)";
    default:          return "var(--muted-foreground)";
  }
}

function initials(lead: Lead) {
  return (lead.firstName[0] + lead.lastName[0]).toUpperCase();
}

// ─── LeadsView ────────────────────────────────────────────────────────────────

export function LeadsView({ activeCtx }: { activeCtx?: CTXEnum }) {
  const [leads, setLeads] = useState<Lead[]>(APOLLO_LEADS);
  const [selected, setSelected] = useState<Lead | null>(null);
  const [search, setSearch] = useState("");
  const [stageFilter, setStageFilter] = useState<LeadStage | "All">("All");

  const filtered = leads.filter(l => {
    const q = search.toLowerCase();
    if (search && !l.firstName.toLowerCase().includes(q) && !l.lastName.toLowerCase().includes(q) && !l.company.toLowerCase().includes(q)) return false;
    if (stageFilter !== "All" && l.stage !== stageFilter) return false;
    return true;
  });

  const updateLead = (id: string, updater: (l: Lead) => Lead) => {
    setLeads(ls => ls.map(l => l.id === id ? updater(l) : l));
    setSelected(prev => prev?.id === id ? updater(prev) : prev);
  };

  const addTrace = (id: string, action: string, actor: TraceActor = "Human") => {
    const ts = new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
    updateLead(id, l => ({ ...l, trace: [...l.trace, { ts, actor, action }] }));
  };

  const changeStage = (id: string, stage: LeadStage) => {
    const current = leads.find(l => l.id === id)?.stage ?? "New";
    const ts = new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
    updateLead(id, l => ({
      ...l,
      stage,
      trace: [...l.trace, { ts, actor: "Human", action: `Stage: ${current} → ${stage}` }],
    }));
  };

  return (
    <div className="h-full flex flex-col overflow-hidden bg-background">

      {/* Header */}
      <div className="px-6 pt-6 pb-4 bg-card border-b border-border flex-shrink-0">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-xl font-bold text-foreground mb-1">Leads</h1>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded"
                style={{ background: "var(--iw-blue)", color: "#fff" }}>
                Apollo {leads.length}
              </span>
              <span className="text-xs text-muted-foreground">Jun 2026 import · CIOs</span>
            </div>
          </div>
          <Button size="sm" style={{ background: "var(--iw-blue)" }}>
            <Plus className="w-3.5 h-3.5" /> Add Lead
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search name or company..."
            className="pl-9 h-9 text-sm bg-secondary border-0"
          />
        </div>

        {/* Stage filter */}
        <div className="flex gap-1.5 flex-wrap">
          {(["All", ...STAGE_ORDER] as const).map(s => (
            <button key={s} onClick={() => setStageFilter(s)}
              className="px-2.5 py-1 rounded-full text-[11px] transition-all"
              style={{
                background: stageFilter === s ? "var(--iw-blue)" : "var(--secondary)",
                color: stageFilter === s ? "#fff" : "var(--muted-foreground)",
                fontWeight: stageFilter === s ? 700 : 400,
              }}>
              {s}
            </button>
          ))}
          <span className="ml-auto text-xs text-muted-foreground self-center">
            {filtered.length} leads
          </span>
        </div>
      </div>

      {/* Lead list */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {filtered.map(lead => (
            <LeadRow
              key={lead.id}
              lead={lead}
              isSelected={selected?.id === lead.id}
              onClick={() => setSelected(lead)}
            />
          ))}
          {filtered.length === 0 && (
            <div className="flex flex-col items-center py-16 text-center">
              <p className="text-sm font-semibold text-foreground mb-1">No leads match</p>
              <p className="text-xs text-muted-foreground">Adjust your search or stage filter.</p>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Entity Stretch detail — shadcn Sheet */}
      <Sheet open={!!selected} onOpenChange={open => !open && setSelected(null)}>
        <SheetContent
          side="right"
          className="p-0 flex flex-col overflow-hidden"
          style={{ width: "min(680px, 90vw)", maxWidth: "none", gap: 0 }}
        >
          {selected && (
            <LeadDetail
              lead={selected}
              onStageChange={stage => changeStage(selected.id, stage)}
              onTrace={(action, actor) => addTrace(selected.id, action, actor)}
            />
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

// ─── LeadRow ──────────────────────────────────────────────────────────────────

function LeadRow({ lead, isSelected, onClick }: {
  lead: Lead; isSelected: boolean; onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-4 w-full px-5 py-4 rounded-xl text-left transition-all hover:shadow-sm"
      style={{
        background: isSelected ? "var(--iw-blue-50)" : "var(--card)",
        border: `1px solid ${isSelected ? "var(--iw-blue)" : "var(--border)"}`,
      }}>

      <Avatar className="h-10 w-10 shrink-0">
        <AvatarFallback className="text-sm font-bold text-white" style={{ background: "var(--iw-blue)" }}>
          {initials(lead)}
        </AvatarFallback>
      </Avatar>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-sm font-semibold text-foreground truncate">
            {lead.firstName} {lead.lastName}
          </span>
          <Badge variant="secondary" className="text-[9px] shrink-0"
            style={{ background: "var(--secondary)", color: stageColor(lead.stage) }}>
            {lead.stage}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground truncate">{lead.company} · {lead.title}</p>
        <p className="text-[10px] text-muted-foreground truncate">{lead.location}</p>
      </div>

      {/* Score */}
      <div className="text-right shrink-0">
        <div className="flex items-center gap-1.5 mb-1">
          <div className="w-16 h-1.5 rounded-full overflow-hidden bg-secondary">
            <div className="h-full rounded-full"
              style={{ width: `${lead.score}%`, background: "var(--iw-blue)" }} />
          </div>
          <span className="text-[10px] font-mono font-bold" style={{ color: "var(--iw-blue)" }}>
            {lead.score}
          </span>
        </div>
        <span className="text-[8px] font-mono px-1.5 py-0.5 rounded"
          style={{ background: "var(--iw-blue)", color: "#fff", fontWeight: 700 }}>
          Apollo
        </span>
      </div>
    </button>
  );
}

// ─── LeadDetail — Entity Stretch inside Sheet ─────────────────────────────────

function LeadDetail({ lead, onStageChange, onTrace }: {
  lead: Lead;
  onStageChange: (stage: LeadStage) => void;
  onTrace: (action: string, actor?: TraceActor) => void;
}) {
  return (
    <div className="flex flex-col h-full overflow-hidden">

      {/* Sheet header */}
      <SheetHeader className="px-8 pt-8 pb-6 bg-card border-b border-border flex-shrink-0">
        <div className="flex items-start gap-4">
          <Avatar className="h-14 w-14 shrink-0">
            <AvatarFallback className="text-lg font-bold text-white"
              style={{ background: "var(--iw-blue)" }}>
              {initials(lead)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 pr-6">
            <SheetTitle className="text-xl font-bold text-foreground mb-1">
              {lead.firstName} {lead.lastName}
            </SheetTitle>
            <SheetDescription className="text-sm text-muted-foreground mb-3">
              {lead.title} · {lead.company}
            </SheetDescription>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary"
                style={{ background: "var(--secondary)", color: stageColor(lead.stage), fontWeight: 700 }}>
                {lead.stage}
              </Badge>
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" /> {lead.location}
              </span>
              <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded"
                style={{ background: "var(--iw-blue)", color: "#fff" }}>
                Apollo {lead.score}
              </span>
              {(lead.region === "EU" || lead.region === "UK") && (
                <Badge variant="outline"
                  className="text-[9px] border-0"
                  style={{ background: "var(--iw-warning-light)", color: "var(--iw-warning)" }}>
                  <Shield className="w-2.5 h-2.5" />
                  {lead.region === "EU" ? "GDPR" : "ICO / PECR"}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Tabs trigger — inside header for sticky effect */}
        <div className="mt-5">
          <Tabs defaultValue="obtain">
            <TabsList className="w-full h-10">
              <TabsTrigger value="obtain" className="flex-1 text-xs gap-1.5">
                See & Obtain
              </TabsTrigger>
              <TabsTrigger value="twin" className="flex-1 text-xs gap-1.5">
                <Brain className="w-3.5 h-3.5" /> Twin's take
              </TabsTrigger>
              <TabsTrigger value="act" className="flex-1 text-xs gap-1.5">
                <Zap className="w-3.5 h-3.5" /> Act
              </TabsTrigger>
            </TabsList>

            {/* Scrollable tab content */}
            <ScrollArea className="h-[calc(100vh-240px)]">
              <TabsContent value="obtain" className="mt-0 p-8 space-y-8">
                <ObtainSection lead={lead} />
              </TabsContent>
              <TabsContent value="twin" className="mt-0 p-8 space-y-6">
                <TwinSection lead={lead} />
              </TabsContent>
              <TabsContent value="act" className="mt-0 p-8 space-y-8">
                <ActSection lead={lead} onStageChange={onStageChange} onTrace={onTrace} />
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </div>
      </SheetHeader>
    </div>
  );
}

// ─── See & Obtain ─────────────────────────────────────────────────────────────

function ObtainSection({ lead }: { lead: Lead }) {
  return (
    <>
      <section>
        <SectionLabel>Profile</SectionLabel>
        <div className="rounded-xl overflow-hidden border border-border">
          {[
            ["Full name",     `${lead.firstName} ${lead.lastName}`],
            ["Title",          lead.title],
            ["Company",        lead.company],
            ["Location",       lead.location],
            ["Industry",       lead.industry ?? "—"],
            ["Company size",   lead.companySize ?? "—"],
            ["Data score",     `${lead.score} / 100 (Apollo)`],
          ].map(([label, value], i, arr) => (
            <div key={String(label)}
              className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: i < arr.length - 1 ? "1px solid var(--border)" : "none" }}>
              <span className="text-xs text-muted-foreground">{label}</span>
              <span className="text-sm font-medium text-foreground">{value}</span>
            </div>
          ))}
        </div>
      </section>

      <Separator />

      <section>
        <SectionLabel>Outreach compliance</SectionLabel>
        <div className="rounded-xl p-5"
          style={{ background: "var(--iw-warning-light)", border: "1px solid var(--iw-warning)" }}>
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4" style={{ color: "var(--iw-warning)" }} />
            <span className="text-xs font-bold" style={{ color: "var(--iw-warning)" }}>
              {lead.region === "EU" ? "GDPR · EU Regulation"
               : lead.region === "UK" ? "ICO / PECR · UK Rules"
               : "CAN-SPAM · US Rules"}
            </span>
          </div>
          <p className="text-sm leading-relaxed text-foreground">
            {lead.region === "EU" && "GDPR Article 6(1)(f) — legitimate interest applies if outreach is professionally relevant. Document your lawful basis before any contact. Avoid automated sequences without documented consent."}
            {lead.region === "UK" && "ICO and PECR — B2B outreach is permissible when professionally relevant to the recipient's role. Document your purpose and relevance. Soft opt-in rules apply for electronic communications."}
            {lead.region === "US" && "CAN-SPAM governs commercial email. B2B outreach is generally permitted. Include a clear opt-out mechanism in all emails sent."}
          </p>
        </div>
      </section>

      <Separator />

      <section>
        <SectionLabel>Sources</SectionLabel>
        <div className="space-y-3">
          {[
            {
              source: "Apollo", status: "complete",
              detail: `Score ${lead.score} · Full profile · Jun 23, 2026`,
              action: null,
            },
            {
              source: "Notion", status: "unlinked",
              detail: "No linked page for this lead",
              action: "Link page",
            },
            {
              source: "GitHub", status: "empty",
              detail: `No activity found for ${lead.company}`,
              action: null,
            },
          ].map(s => (
            <div key={s.source}
              className="flex items-center justify-between px-5 py-4 rounded-xl bg-card border border-border">
              <div className="flex items-center gap-3">
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded"
                  style={{
                    background: s.source === "Apollo" ? "var(--iw-blue)" : s.source === "Notion" ? "var(--foreground)" : "var(--secondary)",
                    color: s.source === "GitHub" ? "var(--muted-foreground)" : "#fff",
                  }}>
                  {s.source}
                </span>
                <div>
                  <p className="text-sm font-medium text-foreground">{s.source}</p>
                  <p className="text-xs text-muted-foreground">{s.detail}</p>
                </div>
              </div>
              {s.status === "complete" && <CheckCircle2 className="w-4 h-4" style={{ color: "var(--iw-success)" }} />}
              {s.action && (
                <Button variant="outline" size="sm" className="text-xs h-7">{s.action}</Button>
              )}
              {s.source === "GitHub" && <GitBranch className="w-4 h-4 text-muted-foreground" />}
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

// ─── Twin's Read ──────────────────────────────────────────────────────────────

function TwinSection({ lead }: { lead: Lead }) {
  return (
    <>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4" style={{ color: "var(--iw-purple)" }} />
          <span className="text-sm font-bold" style={{ color: "var(--iw-purple)" }}>Twin's take</span>
        </div>
        <Badge variant="secondary" className="font-mono text-xs"
          style={{ background: "var(--iw-purple-light)", color: "var(--iw-purple)" }}>
          {lead.twinRead.confidence}% confidence
        </Badge>
      </div>

      {/* 4 beats */}
      {[
        { n: 1, label: "What I see",      content: lead.twinRead.think },
        { n: 2, label: "What I know",     content: lead.twinRead.understand },
        { n: 3, label: "Check this",      content: lead.twinRead.validate },
        { n: 4, label: "My suggestion",   content: lead.twinRead.draft },
      ].map(beat => (
        <div key={beat.n} className="rounded-xl overflow-hidden bg-card border border-border">
          <div className="flex items-center gap-3 px-5 py-3"
            style={{ background: "var(--iw-purple-light)", borderBottom: "1px solid var(--border)" }}>
            <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
              style={{ background: "var(--iw-purple)" }}>{beat.n}</div>
            <span className="text-[10px] font-bold uppercase tracking-widest"
              style={{ color: "var(--iw-purple)" }}>{beat.label}</span>
          </div>
          <p className="px-5 py-5 text-sm leading-relaxed text-foreground">{beat.content}</p>
        </div>
      ))}

      <div className="rounded-xl p-5 bg-secondary border border-border">
        <SectionLabel>Sources cited</SectionLabel>
        <div className="space-y-2 mt-2">
          {lead.twinRead.citations.map(c => (
            <div key={c} className="flex items-center gap-2">
              <div className="w-1 h-1 rounded-full" style={{ background: "var(--iw-purple)" }} />
              <span className="text-xs font-mono text-muted-foreground">{c}</span>
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-muted-foreground text-center leading-relaxed">
        Twin only says things it can back up. Nothing happens until you say so.
      </p>
    </>
  );
}

// ─── Act ──────────────────────────────────────────────────────────────────────

function ActSection({ lead, onStageChange, onTrace }: {
  lead: Lead;
  onStageChange: (stage: LeadStage) => void;
  onTrace: (action: string, actor?: TraceActor) => void;
}) {
  const [activeVerb, setActiveVerb] = useState<string | null>(null);
  const [draftText, setDraftText] = useState("");
  const [committed, setCommitted] = useState(false);

  const commit = (traceAction: string, stage?: LeadStage) => {
    if (stage) onStageChange(stage);
    onTrace(traceAction, "Human");
    setCommitted(true);
    setActiveVerb(null);
    setDraftText("");
    setTimeout(() => setCommitted(false), 4000);
  };

  const verbs = [
    { id: "research",  label: "Mark as Researched",     icon: NotebookPen, stage: "Researched" as LeadStage, trace: "Marked as Researched" },
    { id: "contact",   label: "Mark as Contacted",      icon: Mail,        stage: "Contacted" as LeadStage,  trace: "Initial outreach sent" },
    { id: "qualify",   label: "Qualify this lead",      icon: UserCheck,   stage: "Qualified" as LeadStage,  trace: "Lead qualified — meets criteria" },
    { id: "schedule",  label: "Schedule discovery call", icon: Calendar,   stage: undefined,                 trace: "Discovery call scheduled" },
    { id: "outreach",  label: "Draft outreach",         icon: FileText,    stage: undefined,                 trace: "Outreach drafted and approved" },
    { id: "twin",      label: "Assign to Twin",         icon: Brain,       stage: undefined,                 trace: "Assigned to Twin — added to Bench" },
  ];

  return (
    <>
      {/* Stage selector */}
      <section>
        <SectionLabel>Pipeline stage</SectionLabel>
        <div className="grid grid-cols-4 gap-2">
          {STAGE_ORDER.map(s => {
            const isActive = lead.stage === s;
            return (
              <button key={s}
                onClick={() => !isActive && commit(`Stage: ${lead.stage} → ${s}`, s)}
                className="py-3 rounded-xl text-xs font-medium transition-all"
                style={{
                  background: isActive ? stageColor(s) : "var(--card)",
                  color: isActive ? "#fff" : "var(--muted-foreground)",
                  border: isActive ? "none" : "1px solid var(--border)",
                  cursor: isActive ? "default" : "pointer",
                  fontWeight: isActive ? 700 : 400,
                }}>
                {s}
              </button>
            );
          })}
        </div>
      </section>

      <Separator />

      {/* Action verbs */}
      <section>
        <SectionLabel>Actions</SectionLabel>
        <div className="space-y-2">
          {verbs.map(v => {
            const Icon = v.icon;
            const isActive = activeVerb === v.id;
            const isTwin = v.id === "twin";
            return (
              <div key={v.id}>
                <button
                  onClick={() => setActiveVerb(isActive ? null : v.id)}
                  className="flex items-center gap-3 w-full px-5 py-4 rounded-xl text-left transition-all"
                  style={{
                    background: isActive ? (isTwin ? "var(--iw-purple-light)" : "var(--iw-blue-50)") : "var(--card)",
                    border: `1px solid ${isActive ? (isTwin ? "var(--iw-purple)" : "var(--iw-blue)") : "var(--border)"}`,
                  }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: isActive ? (isTwin ? "var(--iw-purple)" : "var(--iw-blue)") : "var(--secondary)" }}>
                    <Icon className="w-4 h-4"
                      style={{ color: isActive ? "#fff" : "var(--muted-foreground)" }} />
                  </div>
                  <span className="text-sm font-semibold"
                    style={{ color: isActive ? (isTwin ? "var(--iw-purple)" : "var(--iw-blue)") : "var(--foreground)" }}>
                    {v.label}
                  </span>
                </button>

                {isActive && (
                  <div className="mx-1 mt-1 rounded-xl p-5 space-y-4 bg-secondary border border-border">
                    {v.id === "outreach" && (
                      <Textarea
                        autoFocus
                        value={draftText}
                        onChange={e => setDraftText(e.target.value)}
                        placeholder={`Draft outreach for ${lead.firstName}...\n\nTwin's angle: ${lead.twinRead.draft.slice(0, 80)}...`}
                        rows={5}
                        className="text-sm bg-card border-border resize-none"
                      />
                    )}
                    {v.id === "schedule" && (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-muted-foreground mb-1 block">Date</label>
                          <Input type="date" className="h-9 bg-card border-border text-sm" />
                        </div>
                        <div>
                          <label className="text-xs text-muted-foreground mb-1 block">Time</label>
                          <Input type="time" defaultValue="10:00" className="h-9 bg-card border-border text-sm" />
                        </div>
                      </div>
                    )}
                    {v.id === "twin" && (
                      <div className="rounded-xl p-4"
                        style={{ background: "var(--iw-purple-light)", border: "1px solid var(--iw-purple)" }}>
                        <p className="text-sm leading-relaxed text-foreground">
                          Twin will research the profile, draft grounded outreach, monitor signals, and file a structured update to your Bench. You review before anything sends.
                        </p>
                      </div>
                    )}

                    <Button
                      className="w-full h-11 text-sm font-bold"
                      style={{ background: isTwin ? "var(--iw-purple)" : "var(--iw-success)" }}
                      onClick={() => commit(
                        v.trace + (draftText ? ` — "${draftText.slice(0, 50).trim()}..."` : ""),
                        v.stage
                      )}>
                      <Check className="w-4 h-4" />
                      Approve & Commit
                      <span className="ml-auto text-[9px] font-mono opacity-60">x-approval-token</span>
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {committed && (
        <div className="flex items-center gap-3 px-5 py-4 rounded-xl"
          style={{ background: "var(--iw-success-light)", border: "1px solid var(--iw-success)" }}>
          <CheckCircle2 className="w-5 h-5 shrink-0" style={{ color: "var(--iw-success)" }} />
          <div>
            <p className="text-sm font-bold" style={{ color: "var(--iw-success)" }}>Committed to Spine</p>
            <p className="text-xs" style={{ color: "var(--iw-success)" }}>Trace entry appended. Lead record updated.</p>
          </div>
        </div>
      )}

      <Separator />

      {/* Trace */}
      <section>
        <SectionLabel>Trace</SectionLabel>
        <div className="rounded-xl overflow-hidden border border-border bg-card">
          {[...lead.trace].reverse().map((entry, i, arr) => (
            <div key={i} className="flex items-start gap-4 px-5 py-4"
              style={{ borderBottom: i < arr.length - 1 ? "1px solid var(--border)" : "none" }}>
              <div className="w-2 h-2 rounded-full shrink-0 mt-1.5"
                style={{ background: entry.actor === "Twin" ? "var(--iw-purple)" : entry.actor === "System" ? "var(--muted-foreground)" : "var(--iw-success)" }} />
              <div>
                <p className="text-sm text-foreground leading-snug">{entry.action}</p>
                <p className="text-[10px] font-mono text-muted-foreground mt-0.5">
                  {entry.ts} · {entry.actor}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

// ─── Shared ───────────────────────────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground mb-3">
      {children}
    </p>
  );
}
